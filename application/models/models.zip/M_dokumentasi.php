<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_dokumentasi extends CI_Model {
	
	private $table_name1 = "tbl_dokumentasi";


	public function get_dokumentasi($data){
		return $this->db->get_where($this->table_name1,$data);
	}
	
}
