<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_sertifikat extends CI_Model {
	
	private $table_name1 = "tbl_sertifikat_peserta";
	private $table_name2 = "tbl_peserta";


	public function get_sertifikat($email,$kd_event){
		return $this->db->query('SELECT sp.nomor, p.nama_lengkap, sp.link_sertifikat
		FROM '.$this->table_name1.' AS sp
		JOIN '.$this->table_name2.' AS p
		ON sp.kd_peserta = p.`kd_peserta`
		WHERE sp.email = "'.$email.'" AND sp.kd_event = "'.$kd_event.'"
		');
	}
	
}
