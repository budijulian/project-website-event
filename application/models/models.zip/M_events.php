<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_events extends CI_Model {
	
	private $table_name1 = "tbl_events";
	private $table_name2 = "tbl_tiket";
	private $table_name3 = "tbl_format_konfirmasi";
	private $table_name4 = "tbl_level_admin";
	private $table_name5 = "tbl_admin";

	public function tampil_event(){
		return $this->db->query('SELECT * 
		FROM '.$this->table_name1.'
		');
	}
	public function cari_event($katakunci){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE nama_event LIKE "%'.$katakunci.'%" OR
		kategori LIKE "%'.$katakunci.'%" OR
		jenis_tiket LIKE "%'.$katakunci.'%" 
		ORDER BY timestamp DESC
		');
	}
	public function get_event_terbaru($tanggal_now){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE dari_tanggal >= '.$tanggal_now.' ORDER BY dari_tanggal DESC LIMIT 3
		');
	}
	public function get_event($kategori,$jenis_tiket){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE kategori LIKE "%'.$kategori.'%" AND jenis_tiket LIKE "%'.$jenis_tiket.'%" ORDER BY dari_tanggal DESC
		');
	}
	public function get_data_event($data){
		return $this->db->get_where($this->table_name1,$data);
	}
	public function get_data_konfirmasi($data){
		return $this->db->get_where($this->table_name3,$data);
	}
	
// 	public function hapus_data($npm){
//       // menangkap parameter npm dari controler
//       $where = array('npm_kd'=> $npm);
//       $this->db->where($where);
//       $this->db->delete($this->table_name);
//   }


//   public function edit_data($npm){
//      $where = array('npm_kd' => $npm);
//      return $this->db->get_where($this->table_name,$where);
      
//   }
   
// //   model u/ mengubah data
//   public function update_data($where,$data,$table){
//       $this->db->where($where);
//       $this->db->update($table,$data);
//   }


//khusus admin
	public function get_event_all(){
		$this->db->select('*');
        $this->db->from($this->table_name1);
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	public function get_event_panitia($kd_admin){
		$query =  $this->db->query('SELECT e.kd_event, e.nama_event, e.kategori, e.dari_tanggal, e.jenis_tiket
		FROM '.$this->table_name5.' AS a
		JOIN '.$this->table_name4.' AS l
		ON a.kd_admin = l.kd_admin 
		JOIN '.$this->table_name1.' AS e
		ON e.kd_event = l.kd_event
		WHERE l.kd_admin = "'.$kd_admin.'" 
		');
		
		return $query->result_array();
		
	}


}
