<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_peserta extends CI_Model {
	
	private $table_name1 = "tbl_peserta";
	private $table_name2 = "tbl_calon_peserta";
	private $table_name3 = "tbl_tiket_peserta";
	private $table_name4 = "tbl_events";

	public function add_data_user1($data){
		$this->db->insert($this->table_name1,$data);
	}
	public function add_data_user2($data){
		$this->db->insert($this->table_name2,$data);
	} 
	public function check_slot_peserta($kd_event){
		return $this->db->query('SELECT 
		CASE
			WHEN COUNT(p.kd_peserta) >= e.`slot` THEN "Penuh"
			WHEN COUNT(p.kd_peserta) < e.`slot` THEN "Tersedia"
		END AS status_slot
		FROM `tbl_events` AS e 
		JOIN tbl_peserta AS p
		ON e.`kd_event`  = p.kd_event
		WHERE e.`kd_event` = "'.$kd_event.'"
		');
	}
	// copy data calon peserta ke tabel peserta 
	public function add_konfirmasi_data($kd_peserta){
		return $this->db->query('INSERT
		 INTO '.$this->table_name1.' SELECT * 
		 FROM '.$this->table_name2.'
		 WHERE kd_peserta = "'.$kd_peserta.'"
		 ');
	}
	public function delete_data_user2($img_name,$kd_event,$kd_tiket){
		return $this->db->query('DELETE 
		FROM '.$this->table_name2.'
		WHERE bukti_bayar LIKE "'.$img_name.'%" AND 
		kd_event LIKE "'.$kd_event.'%" AND
		kd_tiket LIKE "'.$kd_tiket.'%" LIMIT 1
		');
	}
	public function tampil_event(){
		return $this->db->query('SELECT * 
		FROM '.$this->table_name1.'
		');
	}
	public function cari_event($katakunci){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE nama_event LIKE "%'.$katakunci.'%" ORDER BY timestamp DESC
		');
	}
	//check peserta yang bayaar gratis
  public function check_email_peserta1($email,$event){
	  return $this->db->query('SELECT t.`kd_event`, p.`email` 
	  FROM '.$this->table_name1.' AS p
	  JOIN '.$this->table_name3.' AS t
	  ON t.kd_event = p.`kd_event`
	  WHERE p.email = "'.$email.'" AND t.kd_event = "'.$event.'"
	  GROUP BY p.email, t.kd_event
	  ');
  }
  //check peserta yang bayar
  public function check_email_peserta2($email,$event){
	  return $this->db->query('SELECT t.`kd_event`, cp.`email` 
	  FROM '.$this->table_name2.' AS cp
	  JOIN '.$this->table_name3.' AS t
	  ON t.kd_event = cp.`kd_event`
	  WHERE cp.email = "'.$email.'" AND t.kd_event = "'.$event.'"
	  GROUP BY p.email, t.kd_event
	  ');
  }
  

// 	public function hapus_data($npm){
//       // menangkap parameter npm dari controler
//       $where = array('npm_kd'=> $npm);
//       $this->db->where($where);
//       $this->db->delete($this->table_name);
//   }


//   public function edit_data($npm){
//      $where = array('npm_kd' => $npm);
//      return $this->db->get_where($this->table_name,$where);
      
//   }
   
// //   model u/ mengubah data
//   public function update_data($where,$data,$table){
//       $this->db->where($where);
//       $this->db->update($table,$data);
//   }
}
