<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_kehadiran extends CI_Model {
	
	private $table_name1 = "tbl_events";
	private $table_name2 = "tbl_tiket";
	private $table_name3 = "tbl_format_konfirmasi";
	private $table_name4 = "tbl_level_admin";
	private $table_name5 = "tbl_admin";
	private $table_name6 = "rbl_kehadiran";
	private $table_name7 = "tbl_absensi_peserta";

	public function tampil_event(){
		return $this->db->query('SELECT * 
		FROM '.$this->table_name1.'
		');
	}
	public function cari_event($katakunci){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE nama_event LIKE "%'.$katakunci.'%" OR
		kategori LIKE "%'.$katakunci.'%" OR
		jenis_tiket LIKE "%'.$katakunci.'%" 
		ORDER BY timestamp DESC
		');
	}
	public function get_event_terbaru($tanggal_now){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE dari_tanggal >= '.$tanggal_now.' ORDER BY dari_tanggal DESC LIMIT 3
		');
	}
	public function get_event($kategori,$jenis_tiket){
		return $this->db->query('SELECT *
		FROM '.$this->table_name1.'
		WHERE kategori LIKE "%'.$kategori.'%" AND jenis_tiket LIKE "%'.$jenis_tiket.'%" ORDER BY dari_tanggal DESC
		');
	}
	public function set_data_kehadiran($data){
		return $this->db->insert($this->table_name7,$data);
	}
	public function get_data_kehadiran($where){
		return $this->db->get_where($this->table_name7,$where);
	}
	
// 	public function hapus_data($npm){
//       // menangkap parameter npm dari controler
//       $where = array('npm_kd'=> $npm);
//       $this->db->where($where);
//       $this->db->delete($this->table_name);
//   }


//   public function edit_data($npm){
//      $where = array('npm_kd' => $npm);
//      return $this->db->get_where($this->table_name,$where);
      
//   }
   
// //   model u/ mengubah data
//   public function update_data($where,$data,$table){
//       $this->db->where($where);
//       $this->db->update($table,$data);
//   }


//khusus admin
	public function get_event_all(){
		$this->db->select('*');
        $this->db->from($this->table_name1);
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	public function get_kehadiran($kd_event){
		$query =  $this->db->query('SELECT *
		FROM '.$this->table_name6.' AS a
		WHERE a.kd_event = "'.$kd_event.'" 
		');
		
		return $query->result_array();
		
	}


}
