<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesan extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_pesan');
		

	}
	
		public function index()
	{
		$data['title'] = "Kirim Pesan";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/pesan');
		$this->load->view('admin/footer');

	}
	public function tp_tambah()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/t_pesan');
		$this->load->view('admin/footer');

	}
	
	
}
