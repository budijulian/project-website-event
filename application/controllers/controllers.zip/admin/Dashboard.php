<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_dashboard');
		$this->load->model('m_admin');
		$this->load->model('m_user');
		
		// mengatur zona waktu wilayah 
		date_default_timezone_set('Asia/Jakarta');
		
		
	}
	
	public function index()
	{
		if($this->session->userdata('status') == true){
			$data['t_events'] = $this->m_user->t_events()->result();
			$data['t_ip'] = $this->m_user->t_ip()->result();
			$data['t_peserta'] = $this->m_user->t_peserta()->result();
			//halaman utama admin
			$this->load->view('admin/header');
			$this->load->view('admin/sidebar');
			$this->load->view('admin/dashboard',$data);
			$this->load->view('admin/footer');
			
		}else{
			redirect("admin/login");
		}
		

	}
	public function logout(){
		$this->session->sess_destroy();
			delete_cookie('kode_event');
			delete_cookie('kode_tiket');
		
		redirect(base_url("admin"));
	}
	public function set_login(){
		$username = $_POST['username'];
		$pass = $_POST['pass'];
		$hasil = $this->m_admin->set_login($username,$pass)->result();
		$get_hasil = $this->m_admin->set_login($username,$pass);
		
		$row  = $get_hasil->row_array();
			$session_data = array(
				'kd_admin' => $row['kd_admin'],
				'username'=> $row['username'],
				'status' => $row['status'],
				'nama_admin' => $row['nama'],
				'ket' => $row['ket']
			);
			$this->session->set_userdata($session_data);
		echo json_encode($hasil);
	}
	public function auth_login(){
		$this->load->view('admin/auth_login');
	}
	
	
}
