<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peserta extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_peserta');
		

	}
	public function index()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/peserta');
		$this->load->view('admin/footer');

	}
	public function tp_tambah()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/t_peserta');
		$this->load->view('admin/footer');

	}
	
	
}
