<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kehadiran extends CI_Controller {
	function __construct(){
		parent::__construct();
		
		$this->load->model('m_kehadiran');
		$this->load->model('m_kehadiran');
	}
	
	public function index()
	{
		$data['title'] = "Data Kehadiran";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/kehadiran');
		$this->load->view('admin/footer');

	}
	public function load_data(){
		// check kondisi data event
		if($this->session->userdata('status') == "Admin"){
			$result = $this->m_kehadiran->get_event_all();
		}
		else if($this->session->userdata('status') != "Admin"){
			$kd_event = $this->session->userdata('kd_event');
			$result = $this->m_kehadiran->get_kehadiran($kd_event);
		}
		$no =1;
        foreach ($result as  $value) {
			$tbody = array();

			$aksi= "<button class=' btn btn-sm btn-primary ubah-kehadiran' title='Edit Data' data-toggle='modal' data-id=".$value['kd_event']."><span class='fa fa-pencil text-white'></span></button>";
			
			$tbody[] = $aksi;
            $tbody[] = $no++;
            $tbody[] = $value['timestamp'];
            $tbody[] = $value['kd_event'];
            $tbody[] = $value['nama_lengkap'];
            $tbody[] = $value['nim'];
            $tbody[] = $value['instansi'];
            $tbody[] = $value['fakultas'];
            $tbody[] = $value['nohp'];			
            $data[] = $tbody; 
        }

        if ($result) {
            echo json_encode(array('data'=> $data));
        }else{
            echo json_encode(array('data'=>0));
        }
	}
	public function tp_tambah()
	{
		$data['title'] = "Tambah Kehadiran Baru";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/t_kehadiran',$data);
		$this->load->view('admin/footer');

	}
	public function u_ubah()
	{
		$data['title'] = "Ubah Kehadiran Baru";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/u_kehadiran',$data);
		$this->load->view('admin/footer');

	}
	

	public function auth_login(){

	}
	
	
}
