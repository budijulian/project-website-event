<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Merchandise extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_merchandise');
		

	}
	
	public function index()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/events');
		$this->load->view('admin/footer');

	}
	public function get_merchandise(){

		$hasil = $this->m_merchandise->get_merchandise()->result();
		echo json_encode($hasil);
	}
	public function tp_tambah()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/t_events');
		$this->load->view('admin/footer');

	}
	
	
}
