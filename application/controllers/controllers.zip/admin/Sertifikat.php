<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_sertifikat');
		

	}
	
		public function index()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/sertifikat');
		$this->load->view('admin/footer');

	}
	public function tp_tambah()
	{
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar');
		$this->load->view('admin/pages/t_sertifikat');
		$this->load->view('admin/footer');

	}
	
	
	
}
