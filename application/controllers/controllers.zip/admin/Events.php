<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller {
	function __construct(){
		parent::__construct();
		
		$this->load->model('m_events');
	}
	
	public function index()
	{
		$data['title'] = "Data Event";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/events');
		$this->load->view('admin/footer');

	}
	public function load_data(){
		// check kondisi data event
		if($this->session->userdata('status') =="Admin"){
			$result = $this->m_events->get_event_all();
		}
		else if($this->session->userdata('status') !="Admin"){
			$kd_admin = $this->session->userdata('kd_admin');
			$result = $this->m_events->get_event_panitia($kd_admin);
		}
		$no =1;
        foreach ($result as  $value) {
            $tbody = array();
            $tbody[] = $no++;
            $tbody[] = $value['kd_event'];
            $tbody[] = $value['nama_event'];
            $tbody[] = $value['kategori'];
            $tbody[] = $value['dari_tanggal'];
            $tbody[] = $value['jenis_tiket'];
			$aksi= "<button class=' btn btn-sm btn-primary ubah-event' title='Edit Data' data-toggle='modal' data-id=".$value['kd_event']."><span class='fa fa-pencil text-white'></span></button>"." ".
			"<button class='mt-2 btn btn-sm btn-info lihat-peserta' title='Lihat Peserta' data-toggle='modal' data-id=".$value['kd_event']."><span class='fa fa-user-alt text-white'></span></button>";
			
			if($this->session->userdata('status') =="Admin"){
			$aksi2 = "<button class='mt-2 btn btn-sm btn-danger  hapus-event' id='id' title='Hapus Data' data-toggle='modal' data-id=".$value['kd_event']."><span class='fa fa-trash-o text-white'></span></button>";
			}else{
				$aksi2 =" ";
			}
			
			$tbody[] = $aksi." ".$aksi2;
            $data[] = $tbody; 
        }

        if ($result) {
            echo json_encode(array('data'=> $data));
        }else{
            echo json_encode(array('data'=>0));
        }
	}
	public function tp_tambah()
	{
		$data['title'] = "Tambah Event Baru";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/t_events',$data);
		$this->load->view('admin/footer');

	}
	public function u_ubah()
	{
		$data['title'] = "Ubah Event Baru";
		//halaman utama admin
		$this->load->view('admin/header');
		$this->load->view('admin/sidebar',$data);
		$this->load->view('admin/pages/t_events',$data);
		$this->load->view('admin/footer');

	}
	

	public function auth_login(){

	}
	
	
}
