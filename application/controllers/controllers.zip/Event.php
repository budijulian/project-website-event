<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Event extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('m_events');
		$this->load->model('m_tiket');
		$this->load->model('m_peserta');
		$this->load->model('m_dokumentasi');
		$this->load->model('m_sertifikat');
		$this->load->model('m_kehadiran');
		$this->load->model('m_voucher');
		$this->load->model('m_user');
		// mengatur zona waktu wilayah 
		date_default_timezone_set('Asia/Jakarta');
		
		//check user ip
		$this->check_data_user();
	}
	public function konfirmasi_email2(){
		$this->load->view('pages/konfirmasi_email2');
	}
	
	//  check ip users 
	public function check_data_user(){
		//$sekarang = date('d-m-Y');
		$ip = $this->input->ip_address();
		$result = $this->m_user->check_ip($ip);
		$this->load->library('user_agent');
		if($result->num_rows() == 0){
			$data =array(
			'ip' => $this->input->ip_address(),
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser(),
			'aktif_terakhir'=> date('d-m-Y H:i:s')
			);
			$this->m_user->add_ip_user($data);
		}else{
			$where = array(
				'ip'=> $this->input->ip_address()
			);
			$data =array(
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser()
			);
			$this->m_user->update_data($where,$data);
		}		
	}
	
	public function index()
	{
		if (isset($_GET['q']) AND isset($_GET['kehadiran'])){
				if($_GET['kehadiran'] == "true"){
					if (isset($_GET['data'])){
						if($_GET['data'] == "true"){
							$kd_event = trim($_GET['q']);
							$email = trim($_POST['email']);
							$nim = trim($_POST['nim']);
							$nama = trim($_POST['nama']);
							$instansi = trim($_POST['instansi']);
							$jurusan = trim($_POST['jurusan']);
							$jalur = trim($_POST['jalur']);
							$data = array(
								'kd_event' => $kd_event,
								'nim' => $nim,
								'jalur' => $jalur,
								'nama_lengkap' => $nama,
								'email' => $email,
								'jurusan' => $jurusan,
								'instansi' => $instansi,
								'keterangan' => 'Pending'
							);
							$where = array(
								'email' => $email
							);
							$check = $this->m_kehadiran->get_data_kehadiran($where);
							
							if($check->num_rows() == 0){
								$cookie=array(
									'name' => 'absen',
									'value' => 0,
									'expire' => 7200,
									'domain' => '',
									'path' => '/',
									'prefix' => '',
									'secure' => FALSE
									);
									set_cookie($cookie);
								 $this->m_kehadiran->set_data_kehadiran($data);
							}
							else{ 
								$cookie=array(
									'name' => 'absen',
									'value' => 1,
									'expire' => 7200,
									'domain' => '',
									'path' => '/',
									'prefix' => '',
									'secure' => FALSE
									);
									set_cookie($cookie);
							}
						}
					}

				



					$data['title'] = "Form Kehadiran Peserta";
					$this->load->view('pages/absensi_event',$data);
					$this->load->view('footer');
				}
		}
		else if (isset($_GET['q'])){
			$kode = $_GET['q'];
		$data_kode = array(
			'kd_event' =>$kode
		);
		// $get_event = $this->m_events->get_event($kd_event);
		// //ambil data event
		// $row = $get_event->row_array();
		// $kode = array(
		// 	'kd_event' =>$row['kd_event']
		// );
		// set cookie
		$cookie=array(
			'name' => 'kode_event',
			'value' => base64_encode($kode),
			'expire' => 3600,
			'domain' => '',
			'path' => '/',
			'prefix' => '',
			'secure' => FALSE
			);
		set_cookie($cookie);
		$data['event'] = $this->m_events->get_data_event($data_kode)->result();
		$data['tiket'] = $this->m_tiket->get_tiket($data_kode)->result();
		//check slot event
		$slot = $this->m_peserta->check_slot_peserta($kode);
		$row  = $slot->row_array();
		$status = $row['status_slot'];
		if($status =="Penuh"){                   
			$this->session->set_userdata("text_slot",
			"Penuh");
			$this->session->set_userdata("status_slot",
			"<span id='status_slot' class=' badge badge-pill badge-danger'>Penuh</span>");
		}else{
			$this->session->set_userdata("text_slot",
			"Masih Tersedia");
			$this->session->set_userdata("status_slot",
			"<span id='status_slot' class=' badge badge-pill badge-success'>Masih Tersedia</span>");
		}
		//set_cookie('link',$url,3600);
		$get_event = $this->m_events->get_data_event($data_kode);
		$row  = $get_event->row_array();
		$data['status'] = $row['nama_event'];
		//halaman utama user
		$this->load->view('header2',$data);
		$this->load->view('pages/event',$data);
		$this->load->view('footer');
		}
		
		else{
			$this->load->view('errors/cli/error_404');
		}

		
	}
	public function download_tiket(){
		
		
		ob_start();
		$kode_tiket = get_cookie('kode_tiket');
		$kode_event = get_cookie('kode_event');
		$harga = get_cookie('biaya_akhir');
		$email = $this->session->userdata('email');
		$nama = $this->session->userdata('nama');
		$instansi = $this->session->userdata('instansi');
		$jurusan = $this->session->userdata('jurusan');

        $data = array(
			'kd_event' => base64_decode($kode_event),
			'kd_tiket' => base64_decode($kode_tiket),
			'harga' => base64_decode($harga),
			'nama' => $nama,
			'instansi' => $instansi,
			'jurusan' => $jurusan,
			'email' => $email
		);
		// pecah data array
		$data_event = array(
			'kd_event' => $data['kd_event']
		);
		$data_tiket = array(
			'kd_tiket' => $data['kd_tiket']
		);

		$data['event'] = $this->m_events->get_data_event($data_event)->result();
		$data['tiket'] = $this->m_tiket->get_tiket($data_tiket)->result();
		
		
		$this->load->view('pages/konfirmasi_email',$data);
		
		$html = ob_get_contents();
        ob_end_clean();

		require './assets/html2pdf/autoload.php';

		$pdf = new Spipu\Html2Pdf\Html2Pdf('P','A4','en');
		$pdf->WriteHTML($html);
		$pdf->Output('Data Siswa.pdf', 'D');


	}
	public function check_email_peserta1(){
		if(isset($_POST['email'])){
			$email = $_POST['email'];
			$event = get_cookie('kode_event');
			$event = base64_decode($event);
			$hasil = $this->m_peserta->check_email_peserta1($email,$event)->result();
			echo json_encode($hasil);
		}
		else{}
	}
	public function check_email_peserta2(){
		if(isset($_POST['email'])){
			$email = $_POST['email'];
			$event = get_cookie('kode_event');
			$event = base64_decode($event);
			$hasil = $this->m_peserta->check_email_peserta2($email,$event)->result();
			echo json_encode($hasil);
		}
		else{}
	}


	public function set_tiket(){
		if(isset($_POST['kd_tiket'])){
			$kode = $_POST['kd_tiket'];
			$cookie=array(
			'name' => 'kode_tiket',
			'value' => base64_encode($kode),
			'expire' => 7200,
			'domain' => '',
			'path' => '/',
			'prefix' => '',
			'secure' => FALSE
			);
			set_cookie($cookie);
			}
		else{}
	}
	public function set_datadiri(){
		
				$email = trim($_POST['email']);
				$nim = trim($_POST['nim']);
				$nama = trim($_POST['nama']);
				$nohp = trim($_POST['nohp']);
				$instansi = trim($_POST['instansi']);
				$jurusan = trim($_POST['jurusan']);
				$jalur = trim($_POST['jalur']);
			//membuat session
				$data = array(
				'email' => $email,
				'nim' => $nim,
				'nama' => $nama,
				'nohp' => $nohp,
				'jalur'=>$jalur,
				'instansi' => $instansi,
				'jurusan' => $jurusan,
				'kd_event' => get_cookie('kode_event'),
				'kd_tiket' =>  get_cookie('kode_tiket')
			);
			//membuat session
			$this->session->set_userdata($data);
	}
	// pembayaran tanpa bukti transfer
	public function set_pembayaran1(){
		// inisialisasi data
		$email = $this->session->userdata('email');
		$nim = $this->session->userdata('nim');
		$jalur = $this->session->userdata('jalur');
		$nama = $this->session->userdata('nama');
		$nohp = $this->session->userdata('nohp');
		$instansi = $this->session->userdata('instansi');
		$jurusan = $this->session->userdata('jurusan');
		$kd_event = $this->session->userdata('kd_event');
		$kd_event = base64_decode($kd_event);
		$kd_tiket = $this->session->userdata('kd_tiket');
		$kd_tiket = base64_decode($kd_tiket);
		$no_peserta = "PST".date('Ymd').rand(0, 999);
		$kd_tiket_peserta = "TKP".date('Ymd').rand(0, 999);

		$data_tiket_peserta = array(
			'kd_tiket_peserta' => $kd_tiket_peserta,
			'kd_event' => $kd_event,
			'kd_peserta' => $no_peserta,
			'kd_tiket' => $kd_tiket,
			'bayar' => 0,
			'diskon' => 0,
			'status' => 'Verifikasi',
			'bukti_bayar' => '',
			'keterangan' => 'Berhasil'
		);

		$data = array(
			'kd_peserta' => $no_peserta,
			'kd_tiket' => $kd_tiket,
			'kd_event' => $kd_event,
			'nim' => $nim,
			'jalur' => $jalur,
			'nama_lengkap' => $nama,
			'email' => $email,
			'no_hp' => $nohp,
			'jurusan' => $jurusan,
			'instansi' => $instansi
			//'keterangan' => 'Berhasil',
			//'status' => 'Verifikasi'
		);
			//membuat cookie pada nomor tiket
			$session_data = array(
			'kd_tiket_peserta' => $kd_tiket_peserta,
			'total_bayar' => $bayar,
			'diskon' => 0,
			'waktu_pemesanan' => date('d-m-Y H:i:s'),
			'status' => 'Berhasil'
			);
			$this->session->set_userdata($session_data);
			// menambah data tiket peserta
			$this->m_tiket->add_data_tiket($data_tiket_peserta);
			// menambah data peserta
			$this->m_peserta->add_data_user1($data);
	}
	// pembayaran dengan bukti transfer
	public function set_pembayaran2(){
		// inisialisasi data
		$target_dir = "./assets/img/pembayaran/";
		$name_img = $_FILES["file"]["name"];
		$email = $this->session->userdata('email');
		$nama = $this->session->userdata('nama');
		$nim = $this->session->userdata('nim');
		$jalur = $this->session->userdata('jalur');
		$nohp = $this->session->userdata('nohp');
		$instansi = $this->session->userdata('instansi');
		$jurusan = $this->session->userdata('jurusan');
		$kd_event = $this->session->userdata('kd_event');
		$kd_event = base64_decode($kd_event);
		$kd_tiket = $this->session->userdata('kd_tiket');
		$kd_tiket = base64_decode($kd_tiket);
		$no_peserta = "PST".date('Ymd').rand(0, 999);
		$kd_tiket_peserta = "TKP".date('Ymd').rand(0, 999);
		$bayar = get_cookie('total_bayar');
		$bayar = base64_decode($bayar);
		//mengambil kata awal dari nama peserta
		// $kata = explode(" ",$nama);
		// $name_img = date('Ymd')."-".$kata[0]."-".$name_img;
		$data_tiket_peserta = array(
			'kd_tiket_peserta' => $kd_tiket_peserta,
			'kd_event' => $kd_event,
			'kd_peserta' => $no_peserta,
			'kd_tiket' => $kd_tiket,
			'bayar' => $bayar,
			'diskon' => 0,
			'status' => 'Belum Verifikasi',
			'bukti_bayar' => $name_img,
			'keterangan' => 'Berhasil'
		);

		$data = array(
			'kd_peserta' => $no_peserta,
			'kd_event' => $kd_event,
			'kd_tiket' => $kd_tiket,
			'nama_lengkap' => $nama,
			'email' => $email,
			'nim' => $nim,
			'jalur' => $jalur,
			'no_hp' => $nohp,
			'jurusan' => $jurusan,
			'instansi' => $instansi
		);
		//  $data = array(
        //   'konfirmasi' => 'Berhasil'
        //                 );
		// echo json_encode($data);

		$request = 1;
		if(isset($_POST['request'])){
			$request = $_POST['request'];
		}

		// Upload file
		if($request == 1){
			$target_file = $target_dir . basename($_FILES["file"]["name"]);
			//membuat cookie pada nomor tiket
			$session_data = array(
			'kd_tiket_peserta' => $kd_tiket_peserta,
			'total_bayar' => $bayar,
			'diskon' => 0,
			'waktu_pemesanan' => date('d-m-Y H:i:s')
			);
			$this->session->set_userdata($session_data);
			// menambah data tiket peserta
			$this->m_tiket->add_data_tiket($data_tiket_peserta);
			// menambah data peserta
			$this->m_peserta->add_data_user2($data);
			$msg = "";
			if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_dir.$_FILES['file']['name'])) {
				
				$msg = "Successfully uploaded";
			}else{
				$msg = "Error while uploading";
			}
			echo $msg;
		}

		// Remove file
		if($request == 2){
			// hapus data gambar dan data peserta
			$filename = $target_dir.$_POST['name']; 
			$img_name =  $_POST['name'];
			$this->m_peserta->delete_data_user2($img_name,$kd_event,$kd_tiket);
			unlink($filename); exit;
		}
	}
	//mengambil kode pemesanan peserta
	// public  function check_tiket
	public function check_vouchers(){
		$token = $_GET['token'];
		$hasil = $this->m_voucher->check_voucher($token);
		
		// if($data->num_rows() >= 0){
		// 	$notif = "Valid";
		// }
		// else{
		// 	$notif = "Tidak Valid";
		// }
		// $data = array(
		// 	'status' => $notif
		// )
		echo json_encode($hasil);
	}
	public function pencarian()
	{
		//kata kunci pencarian
		if(isset($_POST['cari'])){

			$katakunci = $this->input->post('cari');
			$data['hasil'] = $this->m_events->cari_event($katakunci)->result();
			$data['status'] = "Pencarian Event";
			//halaman utama user
			
			$this->load->view('header2',$data);
			$this->load->view('pages/pencarian',$data);
			$this->load->view('footer');
		}else{
			redirect(base_url());
		}
	}
	public function get_sertifikat(){
		//menampilkan dokumentasi events
		$kd_event = get_cookie('kode_event');
		$kd_event = base64_decode($kd_event);
		$email = $_POST['email_peserta'];

		$hasil = $this->m_sertifikat->get_sertifikat($email,$kd_event)->result();
		echo json_encode($hasil);
	}
	public function get_dokumentasi(){
		//menampilkan dokumentasi events
		$kd_event = get_cookie('kode_event');
		$data = array(
			'kd_event' => base64_decode($kd_event)
		);
		$hasil = $this->m_dokumentasi->get_dokumentasi($data)->result();
		echo json_encode($hasil);
	}
	public function get_event(){
		// menampilkan data seluruh daftar event
		
		$kategori = $_POST['kategori'];
		$jenis_tiket= $_POST['jenis_tiket'];

		$hasil = $this->m_events->get_event($kategori,$jenis_tiket)->result();
		echo json_encode($hasil);
	}
	public function all_events(){
		// menampilkan data seluruh daftar event
		$hasil = $this->m_events->tampil_event()->result();
		echo json_encode($hasil);
	}
	public function get_event_terbaru(){
		// menampilkan data seluruh daftar event terbaru
		$tanggal_now = date('Y-m-d');

		$hasil = $this->m_events->get_event_terbaru($tanggal_now)->result();
		echo json_encode($hasil);
	}
	
	
}
