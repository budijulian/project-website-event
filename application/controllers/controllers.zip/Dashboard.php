<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('m_events');
		$this->load->model('m_user');
		// mengatur zona waktu wilayah 
		date_default_timezone_set('Asia/Jakarta');
		//check user ip
		$this->check_data_user();
	}
	public function index()
	{
		$data['status'] = "Himasi Event";
		$tanggal_now = date('Y-m-d');
		$data['event_terbaru'] = $this->m_events->get_event_terbaru($tanggal_now)->result();
		//check data homepage
		$data['t_events'] = $this->m_user->t_events()->result();
		$data['t_merchandise'] = $this->m_user->t_merchandise()->result();
		$data['t_ip'] = $this->m_user->t_ip()->result();
		$data['t_peserta'] = $this->m_user->t_peserta()->result();
		//halaman utama user
		
		$this->load->view('header',$data);
		$this->load->view('index',$data);
		$this->load->view('footer');
	}
	//  check ip users 
	public function check_data_user(){
		//$sekarang = date('d-m-Y');
		$ip = $this->input->ip_address();
		$result = $this->m_user->check_ip($ip);
		$this->load->library('user_agent');
		if($result->num_rows() == 0){
			$data =array(
			'ip' => $this->input->ip_address(),
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser(),
			'aktif_terakhir'=> date('d-m-Y H:i:s')
			);
			$this->m_user->add_ip_user($data);
		}else{
			$where = array(
				'ip'=> $this->input->ip_address()
			);
			$data =array(
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser()
			);
			$this->m_user->update_data($where,$data);
		}		
	}

}
