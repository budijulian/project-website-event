<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->model('m_events');
		$this->load->model('m_tiket');
		$this->load->model('m_email');
		$this->load->model('m_user');
		// $this->load->library('email');
		// mengatur zona waktu wilayah 
		date_default_timezone_set('Asia/Jakarta');
		
		//check user ip
		$this->check_data_user();
		
		//define('EMAIL_ADMIN', 'himasiunas@gmail.com');
	}
	
	//  check ip users 
	public function check_data_user(){
		//$sekarang = date('d-m-Y');
		$ip = $this->input->ip_address();
		$result = $this->m_user->check_ip($ip);
		$this->load->library('user_agent');
		if($result->num_rows() == 0){
			$data =array(
			'ip' => $this->input->ip_address(),
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser(),
			'aktif_terakhir'=> date('d-m-Y H:i:s')
			);
			$this->m_user->add_ip_user($data);
		}else{
			$where = array(
				'ip'=> $this->input->ip_address()
			);
			$data =array(
			'os' => $this->agent->platform(),
			'browser' => $this->agent->browser()
			);
			$this->m_user->update_data($where,$data);
		}		
	}


		//public $email_admin = "himasiunas@gmail.com";
	public function delete_session(){
		
			$this->session->sess_destroy();
			delete_cookie('kode_event');
			delete_cookie('kode_tiket');
		
		redirect(base_url());
	}
	public function cari_event(){

		$katakunci = $this->input->post('katakunci');

		$data = $this->m_event->cari_event($katakunci)->result();
		echo json_encode($data);
	}
	public function tampil_event(){
		$data = $this->m_event->tampil_event()->result();
		echo json_encode($data);
	}
	public function datadiri(){
		$kode_tiket = get_cookie('kode_tiket');
		$kode_event = get_cookie('kode_event');
		$data_tiket = array(
			'kd_tiket' => base64_decode($kode_tiket)
		);
		$data_event = array(
			'kd_event' => base64_decode($kode_event)
		);
		if(($kode_event != null) AND ($kode_tiket != null)){
			$data['tiket'] = $this->m_tiket->get_tiket($data_tiket)->result();
			$data['event'] = $this->m_events->get_data_event($data_event)->result();
			
			$this->load->view('pages/datadiri',$data);
		}
		else{
			redirect(base_url());
		}
	}
	public function pembayaran(){
		
		$kode_tiket = get_cookie('kode_tiket');
		$kode_event = get_cookie('kode_event');

		$data_tiket = array(
			'kd_tiket' => base64_decode($kode_tiket)
		);
		$data_event = array(
			'kd_event' => base64_decode($kode_event)
		);
		if(($kode_event != null ) AND ($kode_tiket != null )){	
		$data['tiket'] = $this->m_tiket->get_tiket($data_tiket)->result();
		$data['event'] = $this->m_events->get_data_event($data_event)->result();
		$this->load->view('pages/pembayaran',$data);
		}
		else{
		redirect(base_url());
		}
	}
	
	public function kirim_konfirmasi2($data)
	{
		
		// pecah data array
		$data_event = array(
			'kd_event' =>$data['kd_event']
		);
		$data_tiket = array(
			'kd_tiket' => $data['kd_tiket']
		);

		$data['event'] = $this->m_events->get_data_event($data_event)->result();
		$data['tiket'] = $this->m_tiket->get_tiket($data_tiket)->result();
		$admin_email = "himasiunas@gmail.com";
		$email = $data['email'];
		$subject = "Konfirmasi Pembayaran Event";
		$comment = $this->load->view('pages/konfirmasi_email',$data);
  //send email
  		mail($admin_email, '$subject', $comment, "From:" . $email);
  //Email response
  		echo "Test Successful !!!";
  	}
  //if "email" variable is not filled out, display the form
//   else  {
//   }
	public function set_pesan(){
		        
		// simpen data pesan
		$data = array(
			'email' => $_POST['email'],
			'pesan' => $_POST['pesan']
		);
        	$config = [
            'protocol'  => 'smtp',
            'smtp_pass' => 'A5XB2Okw1Vv6LKG8',
            'smtp_user' => 'budijulian96@gmail.com',
            'smtp_host' => 'smtp-relay.sendinblue.com',
            'smtp_port' => 587,
            // 'smtp_crypto' => 'ssl',
            'smtp_timeout' => 30,
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n",
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
		];
		// $config = [
        //     'protocol'  => 'smtp',
        //     'smtp_pass' => '24budi24',
        //     'smtp_user' => 'himasievent@roflg.xyz',
        //     'smtp_host' => 'mail.roflg.xyz',
        //     'smtp_port' => 587,
        //     // 'smtp_crypto' => 'ssl',
        //     'smtp_timeout' => 30,
        //     'mailtype'  => 'html',
        //     'charset'   => 'utf-8',
        //     'newline'   => "\r\n",
        //     'charset' => 'iso-8859-1',
        //     'wordwrap' => TRUE
		// ];
		//kontanta email admin
		$email_admin = "budijulian96@gmail.com";
		//$email_admin = "himasiunas@gmail.com";

        $this->email->initialize($config);
        $this->email->from($data['email'], 'QUESTION HIMASI EVENT');
        $this->email->to($email_admin);
        // $this->email->attach('');
        $this->email->subject('Kritik dan Saran');
		$this->email->message('
		<h3><strong> Kritik dan Saran : </strong></h3>
		<p>'. $data['pesan'].'</p>');

		//kirim pesan sementara
		//kontanta email admin
		//$email_admin = "budijulian96@gmail.com";
		// $email_admin = "himasiunas@gmail.com";

        // $this->email->initialize($config);
        // $this->email->from($email_admin, 'PANITIA HIMASI EVENT');
        // $this->email->to("Wrdatljnh2607@gmail.com");
        // // $this->email->attach('');
        // $this->email->subject('Pemberitahuan');
		// $this->email->message('
		// <h3><strong> Pemberitahuan </strong></h3>
		// <p>Selamat malam, bapak dan ibu yth. Wrdatljnh2607@gmail.com <br> Kami Panitia HIMASI ingin menyampaikan data yang anda tidak valid pada
		// form pendaftaran event "Forum Diskusi UI/UX Fundamental and Build a Project with Figma". Mohon lampirankan data pendukung yang tepat tertera pada deskripsi event. Terimakasih </p>');



        if ($this->email->send()) {
			# code...
          //echo 'Berhasil';
        } else {
            //echo 'Gagal';
            die;
        }
	}
	public function kirim_konfirmasi($data)
	{
		
        
		// pecah data array
		$data_event = array(
			'kd_event' => $data['kd_event']
		);
		$data_tiket = array(
			'kd_tiket' => $data['kd_tiket']
		);
		
		$data['konfirmasi'] = $this->m_events->get_data_konfirmasi($data_event)->result();
		$data['event'] = $this->m_events->get_data_event($data_event)->result();
		$data['tiket'] = $this->m_tiket->get_tiket($data_tiket)->result();
		
		//menggunakan smtp sendinblue.com
// 		$config = [
//             'protocol'  => 'smtp',
//             'smtp_pass' => '24budi24',
//             'smtp_user' => 'budijulian96@gmail.com',
//             'smtp_host' => 'smtp.gmail.com',
//             'smtp_port' => 587,
//             // 'smtp_crypto' => 'ssl',
//             // 'smtp_timeout' => 30,
//             'mailtype'  => 'html',
//             'charset'   => 'utf-8',
//             'newline'   => "\r\n"
//             // 'charset' => 'iso-8859-1'
//             // 'wordwrap' => TRUE
//         ];
        	$config = [
            'protocol'  => 'smtp',
            'smtp_pass' => 'A5XB2Okw1Vv6LKG8',
            'smtp_user' => 'budijulian96@gmail.com',
            'smtp_host' => 'smtp-relay.sendinblue.com',
            'smtp_port' => 587,
            // 'smtp_crypto' => 'ssl',
            'smtp_timeout' => 30,
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'newline'   => "\r\n",
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
		];
		//kontanta email admin
		$email_admin = "himasiunas@gmail.com";

        $this->email->initialize($config);
        $this->email->from($email_admin, 'Panitia HIMASI');
        $this->email->to($data['email']);
        // $this->email->attach('');
        $this->email->subject('Konfirmasi Pemesanan Event');
        $this->email->message($this->load->view('pages/konfirmasi_email',$data, true));

        if ($this->email->send()) {
			# code...
			$data2 = array(
				'email_pengirim' => $data['email'],
				'kd_tiket' =>$data['kd_tiket'],
				'kd_event' => $data['kd_event'],
				'log_status' =>'Berhasil',
				'keterangan' =>''
			);
			$this->m_email->log_email($data2);
          // echo 'Berhasil';
        } else {
			echo $this->email->print_debugger();
			$data2 = array(
				'email_pengirim' => $data['email'],
				'kd_tiket' =>$data['kd_tiket'],
				'kd_event' => $data['kd_event'],
				'log_status' =>'Gagal',
				'keterangan' =>''
			);
			$this->m_email->log_email($data2);
            //echo 'Gagal';
            die;
        }
	}
	
	public function konfirmasi(){

		$kode_tiket = get_cookie('kode_tiket');
		$kode_event = get_cookie('kode_event');
		$harga = get_cookie('biaya_akhir');
		$email = $this->session->userdata('email');
		$nama = $this->session->userdata('nama');
		$instansi = $this->session->userdata('instansi');
		$jurusan = $this->session->userdata('jurusan');
		
		if($kode_event != null ) {	
		$data_event = array(
			'kd_event' => base64_decode($kode_event)
		);
		$data_konfirmasi_tiket = array(
			'kd_event' => base64_decode($kode_event),
			'kd_tiket' => base64_decode($kode_tiket),
			'harga' => base64_decode($harga),
			'nama' => $nama,
			'instansi' => $instansi,
			'jurusan' => $jurusan,
			'email' => $email
		);
		if($this->session->userdata('kd_tiket_peserta') != null){
			//mengirim nilai ke library email
			$this->kirim_konfirmasi($data_konfirmasi_tiket);
		}else{}
		

		$data['event'] = $this->m_events->get_data_event($data_event)->result();
		$this->load->view('pages/konfirmasi',$data);
		}
		else{
			redirect(base_url());
		}
	}
	
}
