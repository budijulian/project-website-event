
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Kirim Pesan</li>
                        </ol>
                    </nav>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Kirim Pesan</h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col col-lg-6 col-sm-6 col-12">   
                                    <div class="form-group">
                                        <label class="text-dark py-3 col-4" for="">Email Peserta</label>
                                        <input id="email" text="email" class=" form-control-sm col-6 text-dark py-3 ml-2" for=""></input>
                                
                                        <label class="text-dark py-3 col-4" for="">Subjek</label>
                                        <input id="email" text="email" class=" form-control-sm col-6 text-dark py-3 ml-2" for=""></input>
                                    </div>
                                 </div>
                                <div class="col col-lg-6 col-sm-6 col-12">
                                   <span class="fa fa-question-circle mb-2"></span>
                                     <div class="form-group">
                                       <button id="kirim_pesan" class="btn btn-outline-success" type="submit"><span class="fa fa-send-o"></span> Kirim Pesan</button>
                                     </div> 
                                </div>
                                <div class="col col-lg-12 col-sm-12 col-12">
                                <small>Text Body</small>
                                <textarea class="form-control-plaintext" name="text-pesan"></textarea>
                                </div>

                                <!-- <div class="col col-lg-4 col-sm-4 col-4">
                                    <div class="table-responsive">
                                    <table id="dataevent" class="table table-sm table-bordered" class="display" style="width:100%"  cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Peserta</th>
                                                <th>Email </th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody >
                                        
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Peserta</th>
                                                <th>Email </th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div> -->
                           
                         </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->


            </div>
            <!-- End of Main Content -->
<!-- ckeditor  -->
 <script>
 
   CKEDITOR.replace( 'text-pesan' );
   
</script>