
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="#">Peserta</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Data Kehadiran</li>
                        </ol>
                    </nav>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Kehadiran</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive-sm">
                                <table id="dataevent" class="table table-xm table-striped" class="display" style="width:100%"  cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Aksi</th>
                                            <th>No</th>
                                            <th>Kode Event</th>
                                            <th>Nama Event</th>
                                            <th>Kategori</th>
                                            <!-- <th>Penanggung Jawab</th> -->
                                            <th>Jadwal</th>
                                            <th>Keterangan</th>
                                        </tr>
                                    </thead>
                                    <tbody >
                                      
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Aksi</th>
                                            <th>No</th>
                                            <th>Kode Event</th>
                                            <th>Nama Event</th>
                                            <th>Kategori</th>
                                            <!-- <th>Penanggung Jawab</th> -->
                                            <th>Jadwal</th>
                                            <th>Keterangan</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->


            </div>
            <!-- End of Main Content -->

            