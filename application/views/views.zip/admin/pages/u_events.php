
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Tambah Event</li>
                        </ol>
                    </nav>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><?= $title;?></h6>
                        </div>
                        <div class="card-body ">
                            <div class="col-12 mb-3  bg-success rounded">
                                <span class=" fa fa-3x mt-1 mb-1 fa-calendar text-white "></span>
                                <span class=" fa fa-2x mt-1 mb-1 text-white ">Informasi Event </span>
                            </div>
                            <div class="row">
                                <div class=" col col-lg-4 col-sm-6 col-md-12  col-12 col-auto">
                                    <img src="<?=base_url()?>assets/admin/img/logo.png" witdh="50px" height="50px" class="img-thumbnail" alt="">
                                    <a class="text-center" href="#"><p>Lihat</p></a>
                                </div>
                                <div class="col col-lg-4 col-sm-4 col-4 col-12">
                                      <div class="form-group row  text-left">
                                        <label class="col-5" for="">Nama Event</label>
                                        <textarea class="col-6 form-control" placeholder="Nama Event" name="namaevent" id="namaevent" cols="8" rows="3"></textarea>
                                    </div>
                                    <div class="form-group  row  text-left">
                                        <label class="col-5" for="">Dari Tanggal</label>
                                        <input type="date" class="col-6 form-control-sm " name="daritanggal" id="daritanggal">
                                    </div>
                                     <div class="form-group row  text-left">
                                        <label class="col-5" for="">Sampai Tanggal</label>
                                        <input type="date" class="col-6 form-control-sm "  name="sampaitanggal" id="sampaitanggal">
                                    </div>
                                     <div class="form-group row  text-left">
                                        <label class="col-5" for="">Lokasi</label>
                                         <textarea class="col-6 form-control" placeholder="Lokasi Acara" name="lokasi" id="lokasi" cols="8" rows="3"></textarea>
                                    </div>
                                    <div class="form-group row  text-left">
                                        <label class="col-5" for="">Foto</label>
                                        <input type="file" class="col-6 form-control-sm "  name="foto" id="foto">
                                    </div>
                                </div>
                                 <div class="col  col-lg-4 col-sm-6 col-md-12  col-12 col-auto">
                                    <div class="form-group row  text-left">
                                        <label class="col-5" for="">Penyelengara </label>
                                        <input type="text" class="col-6 form-control-sm " placeholder="Nama Penyelenggara" name="penyelengara" id="penyelengara">
                                    </div>
                                     <div class="form-group row  text-left">
                                        <label class="col-5" for=""> Jam</label>
                                         <input type="text" class="col-2 form-control-sm "placeholder="08:00"  name="darijam" id="darijam">
                                          &nbsp;-&nbsp;
                                          <input type="text" class="col-2 form-control-sm "placeholder="12:00"  name="sampaijam" id="sampaijam">
                                            &nbsp;WIB&nbsp;
                                     </div>
                                     <div class="form-group row  text-left">
                                        <label class="col-5" for="">Kategori</label>
                                        <select class="col-6 form-control-sm" name="kategori" id="kategori">
                                            <option value="">-- Pilih Kategori --</option>
                                            <option value="Workshop">Workshop</option>
                                            <option value="Seminar">Seminar</option>
                                            <option value="E-Sport">E-Sport</option>
                                            <option value="Forum">Forum</option>
                                            <option value="Talkshow">Talkshow</option>
                                            <option value="Pelatihan">Pelatihan</option>
                                            <option value="Lainnya">Lainnya</option>
                                        </select>
                                    </div>
                                    <div class="form-group row  text-left">
                                        <label class="col-5" for=""> Jenis Tiket</label>
                                        <input type="text" class="col-6 form-control-sm" placeholder="12:00"  name="jenistiket" id="jenistiket">
                                    </div>
                                    <div class="form-group row  text-left">
                                        <label class="col-5" for=""> Slot Peserta</label>
                                        <input type="text" class="col-4 form-control-sm" placeholder="0"  name="slot" id="slot">
                                         &nbsp;-Peserta&nbsp;
                                    </div>
                                    <div class="form-group row  text-left">
                                        <label class="col-5" for="">Status</label>
                                        <select class="col-6 form-control-sm" name="status" id="status">
                                            <option value="">-- Status --</option>
                                            <option selected value="Segera">Segera</option>
                                            <option value="Buka">Buka</option>
                                            <option value="Tutup">Tutup</option>
                                        </select>
                                    </div>
                                     <div class=" mt-4 col col-lg-12 col-sm-6 col-md-12  col-12 col-auto  text-right">
                                   <button class=" btn btn-outline-primary"><span class="fa fa-save"></span> 1. Simpan</button>
                                     </div>
                                </div>
                                
                                <div class="mt-2 col col-lg-6 col-sm-6 col-md-12  col-12 col-auto ">
                                <label>*Tiket Event</label>
                                    <div class="form-group row text-left">    
                                        <label class="col-5" for=""> Kategori Tiket</label>
                                            <select class="col-4 form-control-sm" name="status" id="status">
                                                <option value="">-- Pilih Tiket --</option>
                                                <option value="Gratis">Gratis</option>
                                                <option value="Reguler">Reguler</option>
                                                <option value="Mahasiswa">Mahasiswa</option>
                                                <option value="Mahasiswa">UMUM</option>
                                                <option value="Mahasiswa">UNAS</option>
                                            </select> 
                                             <small class="col-3">*Max 3</small>
                                    </div>
                                    <div class="form-group row text-left">    
                                        <label class="col-5" for=""> Harga Tiket</label>
                                         <input type="text" class="col-4 form-control-sm" placeholder="0"  name="hargatiket" id="hargatiket">
                                          <small class="col-3">*Rupiah</small>
                                         <label class="col-5 text-white" for="">kosong</label>
                                         <button class=" ml-2 mt-2 col-4 btn btn-sm btn-outline-primary"><span class="fa fa-plus"></span> Tambah</button>
                                    </div>
                                </div>
                                <div class="mt-2 col col-lg-6 col-sm-6 col-md-12  col-12 col-auto">
                                    <small>Tiket Tersedia</small>
                                    <div class="table-responsive">
                                        <table class="table table-xm table-striped">
                                            <thead>
                                                <td>NO</td>
                                                <td>Nama Tiket</td>
                                                <td>Harga/Tiket</td>
                                                <td>Aksi</td>
                                            </thead>
                                            <tbody>
                                                <td>1</td>
                                                <td>tiket gratis</td>
                                                <td>Rp. 0,-</td>
                                                <td><a href="#"><span class='fa fa-trash-o text-danger'></span></a></td>
                                            </tbody>
                                        </table>
                                    </div>

                                  </div>
                                  <div class="mt-2 col col-lg-12 col-sm-6 col-md-12  col-12 col-auto">
                                    <div class="form-group row  text-left">    
                                        <label class="col-12" for=""> Vouchers</label>
                                        <input type="radio" class="col-1 form-control-sm"  name="voucher" id="voucher">
                                        &nbsp;*Pakai Vouchers&nbsp;
                                        <input type="radio" class="col-1 form-control-sm"  name="voucher"  checked id="voucher">
                                        &nbsp;*Tidak Vouchers&nbsp;
                                    </div>
                                  </div>
                                <div class="mt-2 col col-lg-6 col-sm-6 col-md-12  col-12 col-auto">
                                    <label class="col-12" for=""> Deskripsi Event</label>
                                    <textarea class="form-control-plaintext" id="text-deskripsi" name="text-deskripsi"></textarea>
                                </div>
                                 <div class=" mt-2 col col-lg-6 col-sm-6 col-md-12  col-12 col-auto ">
                                    <label class="col-12" for=""> Ketentuan Event</label>
                                    <textarea class="form-control-plaintext" id="text-ketentuan" name="text-ketentuan"></textarea>
                                </div>
                                <div class=" mt-4 col col-lg-12 col-sm-6 col-md-12  col-12 col-auto  text-right">
                                   <button class=" btn btn-outline-primary"><span class="fa fa-save"></span> 2.Simpan</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->


            </div>
            <!-- End of Main Content -->

<!-- ckeditor  -->
 <script>
   CKEDITOR.replace( 'text-ketentuan' );
   CKEDITOR.replace( 'text-deskripsi' );
   
</script>