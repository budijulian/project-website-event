<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Website Pendaftaraan Siswa Baru | SMK 2 Palembang</title>

  <!-- Bootstrap core CSS -->
  <link href="<?=base_url()?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?=base_url()?>assets/css/modern-business.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg shadow-lg bg-white fixed-top">
    <div class="container">
    <img src="<?=base_url()?>assets/img/logo.png"  witdh="40px" height="40px" alt="">
      <a class="navbar-brand" href="<?=base_url()?>"> PSB Online SMK 2 Palembang</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url()?>">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              PSB
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item bg-success" href="<?=base_url()?>pendaftaran">Pendaftaran</a>
              <a class="dropdown-item" href="<?=base_url()?>persyaratan">Persyaratan</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Bantuan
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item" href="#pesan">Pesan</a>
              <a class="dropdown-item" href="#tentang">Tentang</a>
              <a class="dropdown-item " href="<?=base_url()?>lupapassword">Lupa Password</a>
              
            </div>
          </li>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Login
            </a>
            <div class="dropdown-menu dropdown-menu-right row" aria-labelledby="navbarDropdownBlog">
              <form action="">
                <div class="col-lg-12 form-group">
                  <label class="col-lg-4" for="">NISN</label>
                  <input class="col-lg-12 form-control" type="text" name="nisn" id="nisn">
                </div>
                <div class="col-lg-12  form-group">
                  <label class="col-lg-4" for="">Password</label>
                  <input class="col-lg-12 form-control" type="password" name="password" id="password">
                </div>
                <div class="col-lg-12 form-group">
                  <input class="col-lg-8 btn btn-success" type="submit" value="Masuk" name="submit" id="submit">
                </div>
              </form>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <header>
    <div class="card-header">
      <h3 class="text-center text-primary">DATA AKUN SISWA PSB SMK N 2 PALEMBANG</h3>
    </div>
  </header>

  <!-- Page Content -->
  <div class="container">
    <!-- Marketing Icons Section -->
    <div class="row mt-5">
      <div class="col-lg-4 mb-4"></div>
      <div class="col-lg-4 mb-4">
        <div class="card h-100">
          <div class="card-body ">
            <form name="sentMessage" id="contactForm" novalidate>
              <div class="control-group form-group">
                <div class="controls">
                  <label>NISN:</label>
                  <input type="text" class="form-control" id="nisn" required data-validation-required-message="Mohon masukan nomor NISN.">
                  <p class="help-block"></p>
                </div>
              </div>
              <div class="control-group form-group">
                <div class="controls">
                  <label>Password:</label>
                  <input type="password" class="form-control" id="password" required data-validation-required-message="Mohon masukan password.">
                </div>
              </div>
              <div class="control-group form-group">
                <div class="controls">
                  <label>Email:</label>
                  <input type="email" class="form-control" id="email" required data-validation-required-message="Mohon masukan email.">
                </div>
              </div>
              <div class="control-group form-group">
                <div class="controls">
                  <input type="submit" class="form-control btn btn-primary" id="submit" value="Ubah">
                </div>
              </div>
            </form>
            
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-4"></div>
      
    </div>
    <hr class="mt-5" >
    <!-- /.row -->
    <div class=' row mt-5' id='tentang'></div>
    <!-- Features Section -->
    <div class="row mt-5">
      <div class="col-lg-6">
        <h2>VISI MISI</h2>
        <p>SMK N 4 Palembang</p>
        <ul class="list-unstyled">
          <li>
            <strong>Visi</strong>
          </li>
        </ul>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, omnis doloremque non cum id reprehenderit, quisquam totam aspernatur tempora minima unde aliquid ea culpa sunt. Reiciendis quia dolorum ducimus unde.</p>
        <ul class="list-unstyled" >
          <li>
            <strong>MISI</strong>
          </li>
        </ul>
         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, omnis doloremque non cum id reprehenderit, quisquam totam aspernatur tempora minima unde aliquid ea culpa sunt. Reiciendis quia dolorum ducimus unde.</p>
       
      </div>
      <div class="col-lg-6">
        <img class="img-fluid rounded" witdh="200px" height="200px" src="<?=base_url()?>assets/img/logo.png" alt="">
      </div>
    </div>
    <!-- /.row -->

    <hr class="mt-5" id="pesan">
    <!-- /.row -->
    <div class=' row mt-5'></div>
    <div class="row">
      <div class="col-lg-6 mb-4">
        <h3>Tinggalkan Kami Sebuah Pesan</h3>
        <form name="sentMessage" id="contactForm" novalidate>
          <div class="control-group form-group">
            <div class="controls">
              <label>Nama:</label>
              <input type="text" class="form-control" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block"></p>
            </div>
          </div>
          <div class="control-group form-group">
            <div class="controls">
              <label>No HP:</label>
              <input type="tel" class="form-control" id="phone" required data-validation-required-message="Please enter your phone number.">
            </div>
          </div>
          <div class="control-group form-group">
            <div class="controls">
              <label>Email:</label>
              <input type="email" class="form-control" id="email" required data-validation-required-message="Please enter your email address.">
            </div>
          </div>
          <div class="control-group form-group">
            <div class="controls">
              <label>Pesan:</label>
              <textarea rows="10" cols="100" class="form-control" id="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
            </div>
          </div>
          <div id="success"></div>
          <!-- For success/fail messages -->
          <button type="submit" class="btn btn-primary" id="sendMessageButton">Kirim Pesan</button>
        </form>
      </div>
      <div class="col-lg-6 mb-4">
        <!-- Embedded Google Map -->
        <iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?hl=en&amp;ie=UTF8&amp;ll=37.0625,-95.677068&amp;spn=56.506174,79.013672&amp;t=m&amp;z=4&amp;output=embed"></iframe>
      </div>

    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <div class="row text-white">
          <div class="col-lg-12">
            <h5 class="white-text">Kontak</h5>
            <hr>
            <div class="col-lg-6 ">
              <img width="150px" heiht="150px" class="responsive-img "
                src="<?=base_url()?>assets/img/logo.png" alt="">
            </div>
            <div class="col-lg-6">
              <ul class="list-unstyled">
                <li>smaknegeri4@gmail.com </li>
                <li>088-8210-9521</li>
                <li> SMK N 4 Palembang</li>
                <li>Jalan Kenangan no 3 RT 02 RW 10 Kel.Rambutan Kec.Ciracas Jakarta Selatan</li>
                    <!-- <li><a class="white-text" href="#!">
                    088-8210-9521</a></li> -->
              </ul>
            </div>

          </div>
        </div>
      <p class="m-0 text-center text-white">Copyright &copy; 2020</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?=base_url()?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?=base_url()?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
