<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>-</title>

  <!-- Bootstrap core CSS -->
  <link href="<?=base_url()?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <!-- Custom styles for this template -->
  <link href="<?=base_url()?>assets/css/modern-business.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<p>Silahkan buka tautan ini untuk bergabung ke grup WhatsApp Fordis UI/UX Fundamental and Build a Project with Figma <br>
<a href="https://chat.whatsapp.com/FdFJyUr84IC0sVGr4L1HnK">https://chat.whatsapp.com/FdFJyUr84IC0sVGr4L1HnK</a></p>

<p>
<strong>HIMPUNAN MAHASISWA SISTEM INFORMASI UNIVERSITAS NASIONAL</strong><br>
Proudly Present :</br>
FORUM DISKUSI</br>
UI/UX Fundamental and Build a Project with Figma</br>
Forum Diskusi akan dilaksanakan pada:</br>
<span class="fa fa-calendar"></span> Tanggal : 10, 17, 24 dan 30 September 2020</br>
<span class="fa fa-clock-o"></span> Waktu : 16.00 - 17:20 <br>
<span class="fa fa-marker"></span> Tempat : Zoom Meeting Platform</br>
<span class="fa fa-money-bill-alt"></span> HTM : FREE</br>
*Dibuka untuk umum</br>
</br>
PEMBICARA :</br>
 Agil Setiawan, S.T., MM</br>
(UI/UX Research Telkomsel)</br>
MODERATOR : </br>
 Melati Indah Petiwi </br>
(Mahasiswa Sistem Informasi)</br>
</br>
Benefit :</br>
1. E-sertifikat (dibagikan di akhir acara)</br>
2. Relasi</br>
3. Ilmu yang Bermanfaat</br>
4. Door prize (Saldo LinkAja)</br>
</br>
Syarat mendapatkan sertifikat:</br>
1. Wajib mengikuti kegiatan sebanyak 4x pertemuan</br>
2. Wajib follow akun Instagram <a href="https://www.instagram.com/himasi.unas1949/">@himasi.unas1949</a></br>
3. Wajib melampirkan bukti screenshot follow akun Instagram 
<a href="https://www.instagram.com/himasi.unas1949/">@himasi.unas1949</a></br>
*Pendaftaran*</br>
<span class="fa fa-calendar"></span> 28 Agustus 2020 - 8 September 2020</br>
</br><strong>‼️KUOTA TERBATAS</strong></br>
</br>
‌For more information: </br>
-  Angga (0878-7765-0202) </br>
- Fikri  (0877-8448-7281)</br>
</br>
Follow Social Media HIMASI*</br>
Instagram : himasi.unas1949</br>
OA LINE : <a href="https://lin.ee/S1usGrm">https://lin.ee/S1usGrm</a></br>
</p>












  <!-- Navigation -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light  text-white-50 shadow-lg  fixed-top" style="background-color:rgb(200, 0, 0);color:white;">
    <div class="container">
    <img src="<?=base_url()?>assets/img/logohimasi.png" class="float-left" witdh="40px" height="40px" alt="">
      <a class="navbar-brand text-white float-left font-weight-bold" href="<?=base_url()?>">HIMASI EVENT </a>
      <form action="<?=base_url()?>pencarian" method="post" id="pencarian">
       <input class="form-control mr-sm-4 rounded-pill mr-xl-6 mr-lg-4" type="search" placeholder="Cari Event" name="cari" aria-label="Search">
       </form>
       <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link text-white" href="<?=base_url()?>event">Merchandise</a>
          </li>
           <li class="nav-item">
            <a class="nav-link text-white" href="<?=base_url()?>event">Event</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link text-white" href="">Kontak</a>
          </li>
           
          <li class="nav-item">
            <a class="nav-link text-white" href=""></a>
          </li>
          
          <!-- <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              PSB
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
              <a class="dropdown-item bg-success" href="<?=base_url()?>pendaftaran">Pendaftaran</a>
              <a class="dropdown-item" href="<?=base_url()?>persyaratan">Persyaratan</a>
            </div>
          </li> -->
          
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Login
            </a>
            <div class="dropdown-menu dropdown-menu-right row" aria-labelledby="navbarDropdownBlog">
              <form action="">
                <div class="col-lg-12 form-group">
                  <label class="col-lg-4" for="">NISN</label>
                  <input class="col-lg-12 form-control" type="text" name="nisn" id="nisn">
                </div>
                <div class="col-lg-12  form-group">
                  <label class="col-lg-4" for="">Password</label>
                  <input class="col-lg-12 form-control" type="password" name="password" id="password">
                </div>
                <div class="col-lg-12 form-group">
                  <input class="col-lg-8 btn btn-success" type="submit" value="Masuk" name="submit" id="submit">
                </div>
              </form>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
 
  <header>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <!-- Slide One - Set the background image for this slide in the line below -->
        <div class="carousel-item active" style="background-image: url('<?=base_url()?>assets/img/plamplet/mta.jpg')">
          <div class="carousel-caption d-none d-md-block">
            <h3>WELCOME EVENT HIMASI</h3>
            <p>Berintegritas, Bersatu dan Berprestasi.</p>
          </div>
        </div>
        <!-- Slide Two - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: url('<?=base_url()?>assets/img/plamplet/mta.jpg')">
          <div class="carousel-caption d-none d-md-block">
            <h3>-</h3>
            <p>-.</p>
          </div>
        </div>
      
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </header>

  <!-- Page Content -->
  <div class="container">
    <div class="mt-5 mb-5">
        <h1 class="my-4 text-center"><span class="fa fa-calendar"></span> EVENT TERBARU</h1>
        <hr class="col-sm-2 border-secondary mb-4">

        <div class="row">
          <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-80 shadow-lg">
              <a href="#"><img class="card-img-top" src="<?=base_url()?>assets/img/plamplet/mta.jpg" alt=""></a>
              <div class="card-body">
                <h4 class="card-title">
                  <p >MTA CERTIFICATION</p>
                </h4>
                  <ul class="list-unstyled">
                    <li><p ><span class="badge badge-pill badge-primary">Workshop</span></p></li>
                    <li><p><span class="fa fa-calendar"></span> 2:05:2019</p></li>
                    <li><p><span class="fa fa-clock-o"></span> 08:00 - 15:00</p></li>
                    <li><p><span class="fa fa-map-marker"></span> Aula Blok 1 Lt 1 Universitas Nasional</p></li>
                  </ul>
                </div>
            </div>
          </div>
        
        </div>
      </div>
      <hr>
    <!-- end event terbaru -->
    <div class="mt-5 mb-5">
        <h1 class="my-4 text-center"><span class="fa fa-calendar"></span> DAFTAR EVENT</h1>
        <hr class="col-sm-2 border-secondary mb-4">
        <form class="mt-3 mb-3" action="">
          <label for="">Kategori</label>
         <select class="form-control-sm" name="kategori" id="kategori">
           <option value="Workshop">Workshop</option>
           <option value="Seminar">Seminar</option>
           <option value="Lainnya">Lainnya</option>
         </select>
        </form>

        <div class="row">
          <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-80 shadow-lg">
              <a href="#"><img class="card-img-top" src="<?=base_url()?>assets/img/plamplet/mta.jpg" alt=""></a>
              <h2 class=" card-img-overlay text-right" for=""><span class="badge badge-pill badge-info">Habis</span></h2>
              <div class="card-body">
                <h4 class="card-title">
                  <p >MTA CERTIFICATION</p>
                </h4>
                  <ul class="list-unstyled">
                    <li><p ><span class="badge badge-pill badge-primary">Workshop</span></p></li>
                    <li><p><span class="fa fa-calendar"></span> 2:05:2019</p></li>
                    <li><p><span class="fa fa-clock-o"></span> 08:00 - 15:00</p></li>
                    <li><p><span class="fa fa-map-marker"></span> Aula Blok 1 Lt 1 Universitas Nasional</p></li>
                  </ul>
                </div>
            </div>
          </div>
        
        </div>
    </div>
    <!-- /.end daftar event -->

    <div class=' row mt-5' id='tentang'></div>
    <!-- Features Section -->
     <!-- end event terbaru -->
    <div class="mt-5 mb-5">
        <h1 class="my-4 text-center"><span class="fa fa-calendar"></span>MERCHANDISE</h1>
        <hr class="col-sm-2 border-secondary mb-4">
        <!-- <form class="mt-3 mb-3" action="">
          <label for="">Kategori</label>
         <select class="form-control-sm" name="kategori" id="kategori">
           <option value="Workshop">Workshop</option>
           <option value="Seminar">Seminar</option>
           <option value="Lainnya">Lainnya</option>
         </select>
        </form> -->

        <div class="row">
          <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-80 shadow-lg">
              <a href="#"><img class="card-img-top" src="<?=base_url()?>assets/img/plamplet/mta.jpg" alt=""></a>
              <h2 class=" card-img-overlay text-right" for=""><span class="badge badge-pill badge-info">Habis</span></h2>
              <div class="card-body">
                <h4 class="card-title">
                  <p >PDL HIMASI</p>
                </h4>
                  <ul class="list-unstyled">
                    <li><p ><span class="badge badge-pill badge-primary">Baju</span></p></li>
                    <li><p><span class="fa fa-dollar"></span> Harga : 000000</p></li>
                    <li><p><span class="fa fa-map-marker"></span> Aula Blok 1 Lt 1 Universitas Nasional</p></li>
                  </ul>
                </div>
            </div>
          </div><div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-80 shadow-lg">
              <a href="#"><img class="card-img-top" src="<?=base_url()?>assets/img/plamplet/mta.jpg" alt=""></a>
              <h2 class=" card-img-overlay text-right" for=""><span class="badge badge-pill badge-info">Habis</span></h2>
              <div class="card-body">
                <h4 class="card-title">
                  <p >Gantungan Kunci</p>
                </h4>
                  <ul class="list-unstyled">
                    <li><p ><span class="badge badge-pill badge-primary">Accesories</span></p></li>
                    <li><p><span class="fa fa-dollar"></span> Harga : 000000</p></li>
                    <li><p><span class="fa fa-map-marker"></span> Aula Blok 1 Lt 1 Universitas Nasional</p></li>
                  </ul>
                </div>
            </div>
          </div>
        <div class="col-lg-4 col-sm-6 portfolio-item">
            <div class="card h-80 shadow-lg">
              <a href="#"><img class="card-img-top" src="<?=base_url()?>assets/img/plamplet/mta.jpg" alt=""></a>
              <h2 class=" card-img-overlay text-right" for=""><span class="badge badge-pill badge-info">Habis</span></h2>
              <div class="card-body">
                <h4 class="card-title">
                  <p >PDL HIMASI</p>
                </h4>
                  <ul class="list-unstyled">
                    <li><p ><span class="badge badge-pill badge-primary">Baju</span></p></li>
                    <li><p><span class="fa fa-dollar"></span> Harga : 000000</p></li>
                    <li><p><span class="fa fa-map-marker"></span> Aula Blok 1 Lt 1 Universitas Nasional</p></li>
                  </ul>
                </div>
            </div>
          </div>
        
        
        </div>
    </div>
    <!-- /.end daftar event -->


    <hr class="mt-5" id="pesan">
    <!-- /.row -->
    <div class=' row mt-5'></div>
    <div class="row">
      <div class="col-lg-6 mb-4">
        <h3>Tinggalkan Kami Sebuah Pesan</h3>
        <form name="sentMessage" id="contactForm" novalidate>
          <div class="control-group form-group">
            <div class="controls">
              <label>Nama:</label>
              <input type="text" class="form-control" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block"></p>
            </div>
          </div>
          <div class="control-group form-group">
            <div class="controls">
              <label>Email:</label>
              <input type="email" class="form-control" id="email" required data-validation-required-message="Please enter your email address.">
            </div>
          </div>
          <div class="control-group form-group">
            <div class="controls">
              <label>Pesan:</label>
              <textarea rows="10" cols="100" class="form-control" id="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
            </div>
          </div>
          <div id="success"></div>
          <!-- For success/fail messages -->
          <button type="submit" class="btn btn-primary" id="sendMessageButton">Kirim Pesan</button>
        </form>
      </div>
      <div class="col-lg-6  mt-5">
        <!-- Embedded Google Map -->
        <iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?hl=en&amp;ie=UTF8&amp;ll=37.0625,-95.677068&amp;spn=56.506174,79.013672&amp;t=m&amp;z=4&amp;output=embed"></iframe>
      </div>

    </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5"  style="background-color:rgb(150, 0, 0);color:white;">
    <div class="container">
      <div class="row text-white">
          <div class="col-lg-12">
            <h5 class="white-text text-center">Integrasi</h5>
            <hr>
            <div class="col-lg-6 float-left">
             <h1><span class="fa fa-people"></span></h1>
            </div>
            <div class="col-lg-6 float-left text-right">
            </div>

          </div>
          <div class="col-lg-12">
            <h5 class="white-text">Kontak</h5>
            <hr>
            <div class="col-lg-6 float-left">
              <ul class="list-unstyled">
                <li>himasi1949@gmail.com </li>
                <li>HImasi_1939</li>
                <li>Sistem Informasi</li>
                <li>Fakultas Teknologi Komunikasi dan Informatika</li>
                <li>Universitas Nasional</li>
              </ul>
            </div>
            <div class="col-lg-6 float-left text-right">
              <img src="<?=base_url()?>assets/img/logohimasi.png" class="col col-lg-4  col-sm-4 col-md-4"
               witdh="100px" height="100px" alt="Logo Himasi">
            </div>

          </div>
        </div>
      <p class="m-0 text-center text-white">Copyright &copy; 2020</p>
    </div>
    <!-- /.container -->
  </footer>
  <!-- icon fa awesome -->
  <script src="https://use.fontawesome.com/f5efeb45d7.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script src="<?=base_url()?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?=base_url()?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
