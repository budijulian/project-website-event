
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Data Event</li>
                        </ol>
                    </nav>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Barcode</th>
                                            <th>Nama Event</th>
                                            <th>Judul Event</th>
                                            <th>Penanggung Jawab</th>
                                            <th>Jadwal</th>
                                            <th>Keterangan</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>12345</td>
                                            <td>Seminar</td>
                                            <td>Data Analis</td>
                                            <td>Ade Muhammad Nur Fauzi</td>
                                            <td>07/07/2020</td>
                                            <td>FREE</td>
                                            <td>
                                                <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
                                                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i> Edit</a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>67890</td>
                                            <td>Workshop</td>
                                            <td>Belajar Pemograman Website</td>
                                            <td>Budi Julian</td>
                                            <td>07/10/2020</td>
                                            <td>-</td>
                                            <td>
                                                <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
                                                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i> Edit</a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>09876</td>
                                            <td>Workshop</td>
                                            <td>Membangun Aplikasi Android</td>
                                            <td>Muhammad Iqbal</td>
                                            <td>07/11/2020</td>
                                            <td>-</td>
                                            <td>
                                                <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
                                                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i> Edit</a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>12345</td>
                                            <td>Seminar</td>
                                            <td>Menjaga keamanan suatu website</td>
                                            <td>Nabilah Ananda</td>
                                            <td>07/12/2020</td>
                                            <td>-</td>
                                            <td>
                                                <a href="#" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
                                                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-pencil-alt"></i> Edit</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->


            </div>
            <!-- End of Main Content -->
